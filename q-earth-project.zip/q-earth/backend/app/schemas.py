from typing import Literal
from pydantic import BaseModel, Field, model_validator

TaskType = Literal["land_cover", "change_detection", "vegetation", "water", "anomaly"]

class AnalyzeRequest(BaseModel):
    region: str = Field(default="Demo Delta", min_length=1, max_length=120)
    task: TaskType = "land_cover"
    features: list[float] = Field(default_factory=lambda: [0.18, 0.62, 0.34, 0.71], min_length=2, max_length=16)
    temporal_delta: float = Field(default=0.28, ge=0, le=1)
    model_confidence: float = Field(default=0.72, ge=0, le=1)
    pixel_count: int = Field(default=12000, ge=1, le=100_000_000)
    quantum_opt_in: bool = True

    @model_validator(mode="after")
    def finite_features(self):
        import math
        if any(not math.isfinite(x) for x in self.features):
            raise ValueError("features must be finite numbers")
        return self

class AnalyzeResponse(BaseModel):
    region: str
    task: TaskType
    route: Literal["classical", "quantum_candidate"]
    route_reason: list[str]
    complexity_score: float
    change_score: float
    confidence: float
    insight: str
    recommended_action: str
    quantum_status: str
    evidence: dict[str, float | int | str]

class BenchmarkRequest(BaseModel):
    features: list[list[float]] = Field(min_length=4, max_length=1000)
    labels: list[int] = Field(min_length=4, max_length=1000)
    random_state: int = 42

    @model_validator(mode="after")
    def validate_dataset(self):
        if len(self.features) != len(self.labels):
            raise ValueError("features and labels must have the same number of rows")
        width = len(self.features[0])
        if width < 2 or width > 16 or any(len(row) != width for row in self.features):
            raise ValueError("all rows must have the same 2–16 features")
        if len(set(self.labels)) < 2:
            raise ValueError("at least two classes are required")
        return self
