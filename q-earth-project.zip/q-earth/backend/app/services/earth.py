from math import isfinite


def normalized_difference(a: float, b: float, eps: float = 1e-9) -> float:
    """Safe normalized difference (a-b)/(a+b), clamped to [-1, 1]."""
    denom = a + b
    if abs(denom) < eps:
        return 0.0
    return max(-1.0, min(1.0, (a - b) / denom))


def ndvi(nir: float, red: float) -> float:
    """NDVI = (NIR - red)/(NIR + red); inputs must be reflectance-like values."""
    return normalized_difference(nir, red)


def ndwi(green: float, nir: float) -> float:
    """McFeeters-style NDWI = (green - NIR)/(green + NIR)."""
    return normalized_difference(green, nir)


def temporal_change(before: list[float], after: list[float]) -> float:
    """Mean absolute normalized feature difference; 0 means identical vectors."""
    if len(before) != len(after) or not before:
        raise ValueError("before and after must be non-empty vectors of equal length")
    if any(not isfinite(v) for v in before + after):
        raise ValueError("feature vectors must contain finite values")
    diffs = [abs(a - b) for a, b in zip(before, after)]
    # Inputs are expected to be normalized to [0, 1]. Clamp for a stable score.
    return round(sum(diffs) / len(diffs), 4)
