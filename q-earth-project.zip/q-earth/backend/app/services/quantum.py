"""Optional, real Qiskit quantum-kernel experiment adapter.

No metrics are fabricated. If optional dependencies are absent, the caller receives
an explicit status. Quantum training is limited to small datasets because kernel
methods scale poorly as the number of samples grows.
"""


def quantum_environment_status() -> dict:
    try:
        import qiskit  # noqa: F401
        import qiskit_machine_learning  # noqa: F401
        return {"available": True, "status": "installed", "message": "Qiskit and Qiskit Machine Learning are installed."}
    except Exception as exc:
        return {"available": False, "status": "optional_dependencies_missing", "message": "Install backend/requirements-quantum.txt to enable quantum-kernel experiments.", "detail": type(exc).__name__}


def run_quantum_kernel_benchmark(features: list[list[float]], labels: list[int], random_state: int = 42) -> dict:
    """Train and evaluate a small QSVC model if optional Qiskit packages are available."""
    status = quantum_environment_status()
    if not status["available"]:
        return {"status": "unavailable", "reason": status["message"], "metrics": None}

    import numpy as np
    from sklearn.model_selection import train_test_split
    from sklearn.preprocessing import MinMaxScaler
    from sklearn.metrics import accuracy_score, balanced_accuracy_score, f1_score

    X = np.asarray(features, dtype=float)
    y = np.asarray(labels, dtype=int)
    if len(X) > 120:
        return {"status": "skipped_dataset_too_large", "reason": "Quantum kernel demo is capped at 120 rows; use a predeclared small subset.", "metrics": None}
    if X.shape[1] > 8:
        return {"status": "skipped_too_many_features", "reason": "Quantum kernel demo supports at most 8 compact features.", "metrics": None}
    if not np.isfinite(X).all() or len(np.unique(y)) < 2:
        return {"status": "invalid_dataset", "reason": "Finite features and at least two classes are required.", "metrics": None}

    from time import perf_counter
    from qiskit.circuit.library import ZZFeatureMap
    from qiskit_machine_learning.kernels import FidelityQuantumKernel
    from qiskit_machine_learning.algorithms import QSVC

    _, counts = np.unique(y, return_counts=True)
    stratify = y if counts.min() >= 2 else None
    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.25, random_state=random_state, stratify=stratify
    )
    scaler = MinMaxScaler(feature_range=(0, np.pi))
    X_train = scaler.fit_transform(X_train)
    X_test = scaler.transform(X_test)
    feature_map = ZZFeatureMap(feature_dimension=X.shape[1], reps=2, entanglement="linear")
    kernel = FidelityQuantumKernel(feature_map=feature_map)
    model = QSVC(quantum_kernel=kernel)
    started = perf_counter()
    model.fit(X_train, y_train)
    fit_seconds = perf_counter() - started
    predictions = model.predict(X_test)
    return {
        "status": "completed",
        "reason": "QSVC with a ZZFeatureMap was trained on the supplied compact feature set.",
        "metrics": {
            "model": "Qiskit QSVC + ZZFeatureMap",
            "accuracy": round(float(accuracy_score(y_test, predictions)), 4),
            "balanced_accuracy": round(float(balanced_accuracy_score(y_test, predictions)), 4),
            "macro_f1": round(float(f1_score(y_test, predictions, average="macro", zero_division=0)), 4),
            "fit_seconds": round(fit_seconds, 6),
            "test_samples": int(len(y_test)),
            "feature_count": int(X.shape[1]),
            "qubits": int(X.shape[1]),
            "feature_map": "ZZFeatureMap(reps=2, entanglement=linear)",
            "execution": "Qiskit FidelityQuantumKernel default fidelity backend; inspect installed Qiskit configuration for exact simulator/hardware behavior",
        },
    }


def run_quantum_kernel_status() -> dict:
    """Report readiness without implying that a benchmark has already run."""
    status = quantum_environment_status()
    if not status["available"]:
        return {"status": "unavailable", "reason": status["message"], "metrics": None}
    return {
        "status": "ready_not_run",
        "reason": "Quantum packages are installed. Submit a small labeled dataset to /api/benchmark to run QSVC.",
        "metrics": None,
    }
