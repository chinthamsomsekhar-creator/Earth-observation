from time import perf_counter
import numpy as np
from sklearn.metrics import accuracy_score, balanced_accuracy_score, f1_score
from sklearn.model_selection import train_test_split
from sklearn.pipeline import make_pipeline
from sklearn.preprocessing import StandardScaler
from sklearn.svm import SVC
from sklearn.ensemble import RandomForestClassifier


def classical_benchmark(features: list[list[float]], labels: list[int], random_state: int = 42) -> dict:
    X = np.asarray(features, dtype=float)
    y = np.asarray(labels, dtype=int)
    if not np.isfinite(X).all():
        raise ValueError("features must be finite")
    if len(np.unique(y)) < 2:
        raise ValueError("at least two classes are required")
    # Stratify only when every class has enough examples to be represented in test split.
    _, counts = np.unique(y, return_counts=True)
    stratify = y if counts.min() >= 2 else None
    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.25, random_state=random_state, stratify=stratify
    )
    results = []
    for name, model in [
        ("RBF SVM", make_pipeline(StandardScaler(), SVC(kernel="rbf", class_weight="balanced"))),
        ("Random Forest", RandomForestClassifier(n_estimators=120, random_state=random_state, class_weight="balanced")),
    ]:
        start = perf_counter(); model.fit(X_train, y_train); fit_seconds = perf_counter() - start
        pred = model.predict(X_test)
        results.append({
            "model": name,
            "accuracy": round(float(accuracy_score(y_test, pred)), 4),
            "balanced_accuracy": round(float(balanced_accuracy_score(y_test, pred)), 4),
            "macro_f1": round(float(f1_score(y_test, pred, average="macro", zero_division=0)), 4),
            "fit_seconds": round(fit_seconds, 6),
            "test_samples": int(len(y_test)),
        })
    return {"status": "completed", "note": "Metrics are from the supplied dataset and split; not precomputed claims.", "results": results}
