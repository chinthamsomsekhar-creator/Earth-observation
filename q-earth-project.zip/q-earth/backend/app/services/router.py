from dataclasses import dataclass

@dataclass(frozen=True)
class RouteDecision:
    route: str
    score: float
    reasons: list[str]


def route_workload(*, feature_count: int, temporal_delta: float, confidence: float,
                   pixel_count: int, quantum_opt_in: bool = True) -> RouteDecision:
    """Transparent prototype routing policy; not a learned or quantum-advantage claim.

    A quantum candidate is selected only for compact, opted-in workloads that are
    sufficiently complex or uncertain. High-volume image processing stays classical.
    """
    reasons: list[str] = []
    score = 0.0
    if temporal_delta >= 0.25:
        score += 0.30; reasons.append("Temporal features show a notable change signal")
    if confidence < 0.70:
        score += 0.30; reasons.append("Classical confidence is below the 0.70 review threshold")
    if feature_count >= 6:
        score += 0.20; reasons.append("Compact feature representation has higher dimensionality")
    if pixel_count > 250_000:
        reasons.append("Large pixel workload remains on the classical path for scale")
    if not quantum_opt_in:
        reasons.append("Quantum execution was disabled by the request")
    if not reasons:
        reasons.append("Standard workload; classical path is sufficient under current policy")

    suitable = quantum_opt_in and pixel_count <= 250_000 and feature_count <= 8 and score >= 0.30
    if suitable:
        reasons.append("Compact workload meets the prototype's quantum-candidate policy")
        return RouteDecision("quantum_candidate", round(min(score, 1.0), 3), reasons)
    if quantum_opt_in and score >= 0.30 and feature_count > 8:
        reasons.append("Feature count exceeds the current small-circuit limit; reduce features first")
    return RouteDecision("classical", round(min(score, 1.0), 3), reasons)
