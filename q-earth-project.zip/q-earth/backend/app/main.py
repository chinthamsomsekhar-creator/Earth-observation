from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from .schemas import AnalyzeRequest, AnalyzeResponse, BenchmarkRequest
from .services.earth import ndvi, ndwi
from .services.router import route_workload
from .services.models import classical_benchmark
from .services.quantum import quantum_environment_status, run_quantum_kernel_status, run_quantum_kernel_benchmark

app = FastAPI(title="Q-EARTH API", version="1.0.0", description="Classical-first, complexity-aware Earth observation prototype")
app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://localhost:5173", "http://127.0.0.1:5173", "http://localhost:4173"],
    allow_credentials=False, allow_methods=["*"], allow_headers=["*"],
)

@app.get("/api/health")
def health():
    q = quantum_environment_status()
    return {"status": "ok", "service": "q-earth-api", "quantum": q["status"]}

@app.post("/api/analyze", response_model=AnalyzeResponse)
def analyze(req: AnalyzeRequest):
    decision = route_workload(
        feature_count=len(req.features), temporal_delta=req.temporal_delta,
        confidence=req.model_confidence, pixel_count=req.pixel_count,
        quantum_opt_in=req.quantum_opt_in,
    )
    qstatus = run_quantum_kernel_status()
    if req.task == "change_detection":
        insight = "A temporal difference signal is present; verify with aligned, cloud-masked scenes before treating it as a real land change."
        action = "Inspect the change layer, confirm acquisition dates and cloud mask, then validate against reference imagery."
    elif req.task == "vegetation":
        insight = "Vegetation assessment needs NIR and red reflectance to calculate NDVI; compact features can support the prototype route decision."
        action = "Compute NDVI from atmospherically corrected, aligned red/NIR bands and compare against a seasonal baseline."
    elif req.task == "water":
        insight = "Water-pattern analysis should use suitable green/NIR or SWIR indices and account for shadows, turbidity, and seasonality."
        action = "Review the water index with cloud/shadow masks and compare multiple dates before escalating an alert."
    elif req.task == "anomaly":
        insight = "This is a candidate spectral anomaly based on compact features, not a confirmed environmental incident."
        action = "Review neighboring pixels, historical baselines, and independent evidence before taking action."
    else:
        insight = "The workload is represented by a compact feature vector suitable for a classical baseline and an optional small quantum experiment."
        action = "Compare classical baselines first; test a quantum kernel only on the same held-out data and report limitations."
    quantum_status = qstatus["status"] if decision.route == "quantum_candidate" else "not_invoked_classical_first"
    return AnalyzeResponse(
        region=req.region, task=req.task, route=decision.route,
        route_reason=decision.reasons, complexity_score=decision.score,
        change_score=round(req.temporal_delta, 4), confidence=round(req.model_confidence, 4),
        insight=insight, recommended_action=action, quantum_status=quantum_status,
        evidence={"feature_count": len(req.features), "pixel_count": req.pixel_count,
                  "ndvi_formula": "(NIR - Red) / (NIR + Red)",
                  "ndwi_formula": "(Green - NIR) / (Green + NIR)",
                  "ndvi_example": round(ndvi(0.62, 0.18), 4),
                  "ndwi_example": round(ndwi(0.34, 0.62), 4),
                  "data_mode": "user-supplied compact features; no live scene fetched"}
    )

@app.post("/api/benchmark")
def benchmark(req: BenchmarkRequest):
    try:
        result = classical_benchmark(req.features, req.labels, req.random_state)
        result["quantum"] = run_quantum_kernel_benchmark(req.features, req.labels, req.random_state)
        return result
    except ValueError as exc:
        raise HTTPException(status_code=422, detail=str(exc)) from exc
