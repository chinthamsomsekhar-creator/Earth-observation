from fastapi.testclient import TestClient
from app.main import app

client = TestClient(app)


def test_health():
    assert client.get('/api/health').status_code == 200


def test_analyze_returns_explanation():
    response = client.post('/api/analyze', json={"region":"Test Region", "features":[0.1,0.5,0.2,0.8], "temporal_delta":0.3, "model_confidence":0.6, "pixel_count":1000})
    assert response.status_code == 200
    body = response.json()
    assert body['route'] == 'quantum_candidate'
    assert body['route_reason']
    assert 'insight' in body
