from app.services.earth import ndvi, ndwi, temporal_change
from app.services.router import route_workload


def test_ndvi_positive_for_healthy_vegetation():
    assert ndvi(0.7, 0.2) > 0.5


def test_ndwi_formula():
    assert round(ndwi(0.5, 0.3), 3) == 0.25


def test_temporal_change_zero_for_identical_vectors():
    assert temporal_change([0.1, 0.7], [0.1, 0.7]) == 0


def test_router_keeps_large_image_workload_classical():
    decision = route_workload(feature_count=4, temporal_delta=0.9, confidence=0.2, pixel_count=500_000)
    assert decision.route == "classical"
    assert any("classical path" in reason.lower() for reason in decision.reasons)


def test_router_can_mark_small_uncertain_workload_as_candidate():
    decision = route_workload(feature_count=4, temporal_delta=0.1, confidence=0.4, pixel_count=1000)
    assert decision.route == "quantum_candidate"
