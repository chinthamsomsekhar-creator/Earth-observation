"""Run a reproducible, synthetic two-class smoke benchmark (not satellite data)."""
import json
import numpy as np
from app.services.models import classical_benchmark
from app.services.quantum import run_quantum_kernel_benchmark

rng = np.random.default_rng(42)
X0 = rng.normal(loc=-0.6, scale=0.55, size=(32, 4))
X1 = rng.normal(loc=0.6, scale=0.55, size=(32, 4))
X = np.vstack([X0, X1]).tolist()
y = ([0] * len(X0)) + ([1] * len(X1))
report = {
    "dataset": "synthetic two-class feature vectors; not satellite observations",
    "random_seed": 42,
    "classical": classical_benchmark(X, y, 42),
    "quantum": run_quantum_kernel_benchmark(X, y, 42),
}
print(json.dumps(report, indent=2))
