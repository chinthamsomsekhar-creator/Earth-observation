# Architecture notes

## Core design decisions
- **Classical-first:** preprocessing, raster alignment, cloud masking, feature extraction, and high-volume pixel operations remain classical.
- **Complexity-aware:** routing uses visible features (temporal change, confidence, feature count, pixel volume) and emits an explanation.
- **Quantum-on-demand:** the router flags a candidate; it does not assert a quantum model has run. The quantum adapter reports dependency/readiness status honestly.
- **Research-ready:** benchmark API uses caller-supplied labeled vectors and returns metrics from a repeatable split.

## Current prototype boundaries
- Map is illustrative and has no real basemap tiles.
- Region selector is a UI control only; it does not query a satellite service.
- Current analysis endpoint receives compact feature vectors, not image files.
- NDVI/NDWI helpers are included, but real band rasters must be aligned, masked, and reflectance-calibrated before use.
- Quantum adapter reports availability/readiness. It intentionally does not invent QML metrics; add and validate a pinned Qiskit experiment before presenting results.

## Next implementation milestones
1. Add Copernicus Data Space OAuth/catalog client and cache metadata safely.
2. Add raster upload and band alignment/cloud masking pipeline.
3. Add labeled EuroSAT training script and scene-level evaluation.
4. Add a pinned, tested quantum-kernel experiment and save circuit artifacts.
5. Add map tiles, spatial geometry selection, and result overlays.
