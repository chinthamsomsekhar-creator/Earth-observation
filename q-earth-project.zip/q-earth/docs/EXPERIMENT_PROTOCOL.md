# Q-EARTH experimental protocol

## Research question
Does a small quantum-kernel model provide a measurable benefit for a specific compact Earth-observation classification task compared with strong classical baselines, and under what data/noise conditions?

## Data and provenance
- Use labeled EuroSAT samples for an initial land-cover experiment, or a documented Sentinel-2 scene with defensible labels.
- Record dataset version, license, scene/product IDs, acquisition dates, CRS, band resolution, cloud mask, and preprocessing parameters.
- Never describe synthetic dashboard traces as satellite observations.
- For change detection, use aligned before/after scenes and a suitable reference label source. Raw difference alone is not proof of a real-world event.

## Experimental design
1. Define a single task and label set before model selection.
2. Build identical train/validation/test splits for every model. Prefer scene-level or geographic splits to reduce spatial leakage.
3. Preprocess all bands consistently; document scaling and feature selection.
4. Fit classical baselines first: RBF SVM and Random Forest are included in this repository.
5. Reduce to a compact feature vector (for example 2–8 features) before quantum encoding. Fit dimensionality reduction on training data only.
6. Run a Qiskit quantum-kernel experiment with a pinned dependency set. Save circuit, feature map, shots/simulator configuration, random seeds, and exact package versions.
7. Repeat across multiple seeds where practical. If using hardware, record backend, job ID, queue/measurement settings, and date.
8. Report accuracy, balanced accuracy, macro F1, per-class recall, fit/inference time, preprocessing time, and uncertainty across seeds.
9. Test noise sensitivity and vary feature count/circuit depth. Compare the router against a simple classical-only policy.
10. Publish raw metric tables and failed runs as well as best results.

## Router validation
The included router is a transparent, hand-set heuristic. It is not a trained complexity predictor. To evaluate it:
- Define an escalation target independently (e.g. low classical confidence or a validated high-complexity workload).
- Measure escalation rate, false escalation rate, missed escalation rate, total latency, and cost proxy.
- Tune thresholds only on validation data, then report held-out performance.
- Keep large image preprocessing classical; do not send raw imagery directly into a quantum circuit.

## Claims policy
Do not claim quantum advantage from a single small test or from simulator wall-clock time. A defensible claim requires fair baselines, repeated experiments, transparent overhead accounting, and a task-specific improvement that exceeds uncertainty. The app currently labels synthetic data and unrun quantum experiments explicitly.
