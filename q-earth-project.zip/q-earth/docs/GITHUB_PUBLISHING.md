# Publishing to GitHub

1. Create a GitHub repository (or choose the existing team repository) and push this folder.
2. Open **Settings → Pages** and set the build/deployment source to **GitHub Actions**.
3. Push to `main` or run **Deploy dashboard to GitHub Pages** from the Actions tab.
4. The dashboard will run in demo mode on Pages. The FastAPI backend must be deployed separately to a host that supports Python containers; then set `VITE_API_BASE_URL` to that backend URL and rebuild the frontend.

The GitHub Pages site is only the frontend. Do not expose Copernicus or IBM credentials in frontend code; keep secrets in backend environment variables.
